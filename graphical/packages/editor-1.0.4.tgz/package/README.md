# Graphical editor

`@graphical/editor` converts a React app onto Graphical's token system and installs a development-only editor on its pages. The package supplies the editor, the install script and the style analyzer; your app supplies its tokens and pages.

## Install

Retain the supplied `editor.tgz` inside your app as `graphical/packages/editor-VERSION.tgz`, replacing `VERSION` with the version in the archive's manifest. Follow the accompanying `install.md` for integrity and compatibility checks. Install using your app's package manager and a project-relative path, for example:

```sh
npm install --save-dev ./graphical/packages/editor-VERSION.tgz
```

Preserve your app's dependency versions, ranges, overrides and lockfile policy. The editor bundles its own UI and motion libraries and the declarations its public API needs; installing those implementation libraries or disabling TypeScript declaration checks is unnecessary. React and React DOM remain the app's own instances. The analyzer and install script use Graphical's pinned TypeScript compiler dependency, installed automatically with the editor. It is separate from the app's compiler, so TypeScript 7 apps keep their version without a compatibility shim. Graphical also owns its CSS parser. JavaScript apps need no app-level compiler or parser dependency. The installed editor uses React DOM and browser APIs, with no Next.js runtime dependency: keep the app's framework, router and styling setup, and pass its committed visible route through the adapter.

Package setup requires Node 20.9 or newer. The installer checks this before writing files, and reports missing setup tools without changing dependencies automatically. If the app uses an older Node runtime, use a supported runtime for setup or report that incompatibility; do not silently upgrade its runtime or framework. The authoring repository's Node requirement is separate from this package floor.

The React/React DOM peer minimum is 19.0. Package builds check runtime imports against the public React 19.0 exports, including code reached through the editor's shared components. Custom font file selection and drag-and-drop use the same compatible callback helper as other editor controls; they do not require React 19.2 or `useEffectEvent`. Browser font loading and local font storage requirements still apply.

Follow the accompanying `skills/graphical-import/SKILL.md`. Importing installs Graphical in one pass, in the user's authorized checkout or requested branch, with no preview stage:

1. Analyze the app with `analyzeAppStyles` from `@graphical/editor/analyze-styles` and write `graphical/install/import.json`. For Tailwind 3 it loads the app's config itself.
2. Run `npx graphical-install` (`installConversion()` from `@graphical/editor/install`). It converts the app, rewrites its use sites, cleans up and groups the class lists it rewrote, formats them with the project's Prettier, and writes the `graphical/` project: the active theme and role map, `generated/` for `theme.css`, `aliases.css` and Graphical's classes for Tailwind 3 or 4, and `install/` for the report. Corners and strokes are `corner-*` and `edge-*`, so Tailwind's `rounded-*` and `border-*` keep their meaning.
3. Put the generated files in place of the app's token definitions, install fonts and mount `GraphicalInstalledEditor`.
4. Re-run the analysis and `npx graphical-install --check`: nothing is left to convert.

The app's pages then run on Graphical, with one theme named Graphical. Later theme changes use `skills/graphical-adopt/SKILL.md` and `npx graphical-install --theme <id>`. `@graphical/editor/install.md`, shipped inside this package with every editor and consumer skill and the shared GUI guidance templates, registers the skills and guidance. Keep the editor and its imports development-only; production renders the converted source, `graphical/generated/theme.css` and installed fonts. The type system and install contract are described in the import skill's references.

Keep installation verification brief: do not add tests or test harnesses, or run broad test suites, production builds, broad type/lint checks or audits. Run at most one existing targeted check if changed behavior warrants it. If project instructions require broader checks, report that requirement separately instead of expanding this installation run.

## Authoring preview

Import doesn't use the preview; it remains for authoring studies. `GraphicalPreviewWorkspace` composes your app’s real React screen and compact figures with isolated sample providers, using a `ThemeDocument` derived from its actual styling. No iframe, separate app route, `src`, readiness selector or handoff endpoint is required:

```tsx
import { GraphicalPreviewWorkspace } from '@graphical/editor/live';
import '@graphical/editor/styles.css';
import { document, App, figures, Scope, SampleProvider } from './preview-content';

<GraphicalPreviewWorkspace
  initialDocument={document}
  App={App}
  figures={figures}
  Scope={Scope}
  Provider={SampleProvider}
/>;
```

Each figure is an `{ id, label, Component }` entry; use stable source-backed components with short representative fixtures. `PreviewFigureFrame` keeps presentation bounded and centers intrinsic content while full-width app controls retain their authored width. Forms and dialogs should show their inline content immediately, not just an opening trigger.

`App` and each figure receive `document`, `colorMode`, `appearance` and `active`. `Scope` optionally provides host styles and a portal boundary for each canvas. `Provider` optionally supplies sample state across both canvases; it renders outside the editor session, so theme, inspector and undo updates never re-render it. Load your app's CSS and fonts in its adapter. An optional `Icon` renders one glyph by index. The initial tab is Theme; the App canvas mounts right after the first paint (or immediately when opened). Switching tabs preserves app state and each tab's scroll position. A hidden tab keeps its state but receives updates only when shown, so don't rely on a hidden canvas rendering. Import preview APIs from `@graphical/editor/live` only: it also exports `GraphicalProvider`, `useGraphicalTheme` and `useGraphicalIconTheme`, while the root entry additionally loads the native editor.

Seed the initial palette from actual app usage, with up to ten meaningful palette accents and separate neutral/status roles. Do not inherit four demo colors or fill unused slots. The import skill's `starting-palette.md` explains usage ranking, alias/tint synthesis, mode pairing and preserving extra colors without changing the app during setup.

Compare is the third icon-only interaction mode alongside Play and Click, to the left of Theme/App. Entering it clears element selection; selecting Play or Click closes comparison. Active mode icons are filled and inactive icons are outlined. Compare overlays the original theme on the left and the edited theme on the right. Its draggable divider starts centered; arrow keys adjust it, Shift moves in larger steps, Home/End reveal either version, double-click centers it, and Escape closes comparison. Only the visible canvas mounts a read-only reference, with the same color mode and shared `Provider` but the baseline document/appearance and `active: false`. Keep service effects and focus traps suspended for inactive content. The edited canvas stays mounted, and corresponding form values and nested scroll positions are mirrored into the reference. Component-local hook state is independent between renders; keep shared sample state in `Provider`. Dragging changes only the CSS reveal position, adds no undo history, and does not rerender host content. Direct component style edits are excluded from the original reference.

`resolveHostTokenOverrides(document, baseline, roleMap, { mode })` from `@graphical/editor/live` lets a host Scope apply only edited variables while its stylesheet retains exact original defaults. It resolves token dependencies and returns `values`, `css` and `issues`. Use the same bindings for App, figures and their portals. `HostIconProvider` from the same entry point connects the app's available icon catalogs; forward its family, variant, weight and SVG props.

Omitting `handoff` uses the package's installation prompt and `install.md`. Its `graphical-preview-install-v1` payload includes accepted foundations, their baseline, appearance, source-backed element edits and asset requirements. It excludes library specimen recipes and hidden popup-scale/press-distance defaults; the install guide specifies how to merge these partial foundations into a complete editor document while preserving app behavior.

An optional `handoff.createPrompt` receives `{ baseline, accepted, colorMode, appearance, elementEdits?, iconEdits?, simplification? }` for integrations that save their own handoff. Preserve the package installation contract and element ownership. The controls append icon replacements and an enabled simplification plan automatically; custom prompts should not serialize those fields a second time. Supply `iconFamilies` for host-rendered icons using `useGraphicalIcon`; preview glyph edits share undo and remain scoped to their instances.

## Iframe fallback

Use `GraphicalLivePreview` only when a concrete compatibility or isolation boundary requires a separately running route, or the user explicitly requests it. Record the reason. An existing demo URL alone does not require an iframe. The `src`, readiness-selector, frame-header and optional persisted-handoff requirements below apply only to this fallback.

```tsx
import { GraphicalLivePreview } from '@graphical/editor/live';
import '@graphical/editor/styles.css';
import { roleMap } from './role-map';
import { figures } from './preview-figures';

<GraphicalLivePreview
  roleMap={roleMap}
  src="/graphicalui/app"
  readySelector='[data-graphical-preview-ready="main"]'
  appName="Acme"
  figures={figures}
  handoff={{
    endpoint: '/graphicalui/handoff',
    skills: '/absolute/path/to/bundle/skills',
  }}
/>;
```

Mount `GraphicalLivePreview` once on the app's preview route. It provides Theme/App tabs, the sidebar, Original/Graphical comparison, light/dark mode, undo and Install/Update theme. Theme contains Typography, Colors and Icons foundation blocks plus your app's figures.

`src` must identify a same-origin view built from your app's real components. Reuse a representative public demo or create an isolated development-only view with sample data and narrow providers. The default view needs no sign-in or real backend. The example `/graphicalui/app` route must be implemented by your app.

`readySelector` must match only the intended loaded view after its data, providers and styles are ready. Graphical waits for that signal before reading the theme and checks it again after navigation. Login, loading and error screens must never match it. Edits change only mapped values; Original restores the app's baseline. Connect all theme-controlled styles in the App view and figures, including typography/line height, spacing, state styles, focus, elevation, motion, icons and portal scopes, with exact source defaults. Follow the import skill's token-coverage reference.

Each figure is an `{ id, label, Component }` entry. Its component receives `{ document, colorMode, appearance, active }`. Use stable component definitions and the app's own styling and assets. Supply twelve complementary figures where appropriate; navigation belongs in App. Suspend focus traps, autoplay and service effects while a figure is inactive.

Development-only handoff routes use `handleGraphicalHandoff`, `graphicalHandoffApi` or `saveGraphicalHandoff` from `@graphical/editor/server`. Install theme saves the accepted changes and opens a compact prompt card in the sidebar for the accompanying adoption skill. Copy prompt copies the full handoff; closing the card returns to Install theme. Further theme changes invalidate the prepared prompt.

## Installed editor

Load the native editor through `GraphicalEditorLoader` from the lightweight `@graphical/editor/loader` entry, inside the app's compile-time development branch. Its `loadEditor` callback can asynchronously load an app-owned adapter and return it as `{ GraphicalInstalledEditor: module.default }`. Read project JSON and import native code/CSS inside that adapter, so module and validation failures restore the host app. Keep durable providers above the loader: successful initial loading and error recovery remount its children; normal panel opening/closing does not. The import/adoption skill contains the complete integration pattern.

Use `readGraphicalProject(project, themeRegistry, roleMap)` to resolve `project.active` from imported theme files. The registry keys match `project.themes[].path`; the helper returns `document`, `roleMap` and `handoffContext`. Keep a stable `project.id` in project.json (new installs generate one), and pass the returned context to the editor. The optional fourth argument sets `projectPath` when it differs from `graphical/project.json`. Invalid or unsupported saved schemas fail before editor effects run.

Copy for agent produces a readable edit script: the captured theme path, source targets and their scope, and changed values written as `before → after`. `$token` means `var(--token)`. Verified committed inline or stylesheet assignments retain their exact tokens and aliases; `observed 12px` identifies a rendered fallback without claiming a source literal. Short text labels (up to 80 characters) help locate targets. Set `handoffPrivacy={{ includeText: false }}` to omit them, or sanitize permitted text/routes and exclude private subtrees. `[data-graphical-private]` always excludes a subtree; query/fragment context stays private by default. Package metadata, unchanged tokens, runtime stacks and hashes are omitted. The adoption skill verifies source targets, reports ambiguous matches or conflicts, and skips already-applied changes; it also accepts older JSON batches.

Import mounts the editor; later theme and element changes follow the accompanying `skills/graphical-adopt/SKILL.md`.

`GraphicalInstalledEditor` from `@graphical/editor/native` mounts once around the development app with `document`, `roleMap` and the current `route`; `readProjectTheme` and `readRoleMap` read the project's JSON files as those types. `initialPanelOpen` opens it on Theme when a page loads; otherwise it starts as a collapsed launcher. It follows the app's color mode by the role map unless `colorMode` is passed. Theme is one continuous panel: a Style dropdown (Current plus Graphical styles), then Character, followed by collapsed foundation adjustments. Edit Color 1 directly in Colors; the installed panel has no brand color control. Selecting page content opens style controls, with Typography as Font, Size and Weight sliders. Size edits a linked text style. Existing line-height/tracking overrides or a custom size automatically expose separate Text size, Line height and Letter spacing controls, without an override summary. The unlink button also opens these controls manually; the link button restores the current size token’s matching line height and tracking in one undoable edit. A custom size must first be assigned a size token to relink. Optional `navigationRoute` identifies the outer URL when the visible app uses nested routing. The native editor uses browser React DOM and has no Next.js runtime dependency; preserve the app's framework and router.

The open inspector occupies its own layout column, leaving the remaining width for the app. App shells must size to their parent. The optional `onAppPortalContainerChange` callback supplies a stable app portal destination inside that viewport; connect it to your app's portal provider when necessary.

The component-based preview and installed editor use available React development ownership and JSX creation-site evidence to recognize the same styled part and variant across instances. No host-specific identifiers are required. Titles and subtitles, labels and descriptions, and different variants stay independent even when one component owns them or their initial styles match. Next's existing development source maps can resolve a captured frame to its app file and render line; copied context never includes source snippets. Missing, truncated or ambiguous metadata falls back to the selected instance; a nearest component name may remain as a search hint, not proof of shared scope. Verified repeated local collections stay limited to that collection. The browser does not read the repository filesystem or reconstruct a complete TSX syntax tree. Handoff preserves each target's actual scope and uses temporary locators only as source-finding evidence.

Selection activates matching on demand. The selected part responds immediately while peer discovery runs in bounded animation-frame batches (4ms target, at most 128 visited elements). Only selected groups receive locators; hidden/inert canvases are skipped until revealed. Subsequent edits repaint visible peers together through one shared CSS rule, without rewriting every matching node or rerendering the preview app/figures. Newly mounted instances join progressively; inline animation styles and editor stylesheet changes do not restart discovery.

Adjust → Colors includes the website editor's cycling Neutrals (Warm / Mono / Cool) and Primary action (Brand / Neutral) rows above the color wells. Both edit the same theme draft used by App, Theme, undo/reset and adoption.

Optional `styleOwners: readonly ComponentStyleOwner[]` supply source labels and paths. Explicit development-only component, part, variant and state markers remain supported as precise overrides. Temporary automatic DOM locators are session-only and must never be copied into app source; handoff records the source context for applying each edit to its authored owner.

## Full icon catalogs

The preview and installed editor share a searchable, virtualized icon picker. Graphical owns its free Lucide outline and Phosphor dependencies: both install automatically with the development editor, independently of any app icon version. Their full catalogs load on demand and are cached per family. Exploring a family does not change app imports or production dependencies. New glyphs keep their vendor names (`lucide:ZoomOut`, `phosphor:Acorn`) through replacement, undo and handoff. They remain in that family when no cross-family semantic mapping exists. Lucide custom filled artwork and the authoring preview's Central samples disclose their limited coverage. Central requires the receiving app's licensed assets; the package never includes that artwork.

Adjust → Icons includes an independent Weight slider for supported artwork: Thin / Light / Regular / Bold for Phosphor outlines, 1–3px for Lucide and Hugeicons Standard outlines, and three Central weights. Filled families without weight variants omit the slider. An authored `theme.iconWeight` participates in undo, reset and copied changes without changing text weight. Existing host icon wrappers must forward the value from `useGraphicalIconTheme()` to their own renderer.

Hugeicons Pro is optional and host-owned. Install the host's licensed `@hugeicons/react` and Standard stroke/solid packages separately. `createHugeiconsRenderer` and `IconRendererProvider` from `@graphical/editor/native` connect them: create a renderer once, provide `loadCatalog(variant)` returning the appropriate installed catalog and `renderGlyph(icon, svgProps)` rendering the host's `HugeiconsIcon`, and wrap the editor and app in the provider. Forward the supplied SVG identity, accessibility and style props, including stroke width. The connected family appears in Adjust and its full catalog is searchable. Catalog errors offer retry. Pro artwork and registry credentials are never bundled with the editor. Keep credentials in the install process's local environment, outside source and copied prompts. Existing custom app icons still need their own renderer bridge; connecting a catalog does not rewrite app components.

For an existing app wrapper, connect `useGraphicalIcon`, forward its identity props and actually render its resolved name. Supply the same `iconFamilies` to preview and installed editor. Cover all available glyphs from the app's own installed version, including those not currently used: list the glyphs the app renders by default in `icons`, and return the rest of a large family from the optional `loadIcons()` instead of loading whole catalogs during mount. The editor calls it once per family id when one of its icons is selected or its picker opens; loaded glyphs join the listed ones (listed names win) and the picker count grows when they arrive, with no loading copy. `renderIcon` must draw loaded glyphs, and `catalog` describes `icons` and `loadIcons` together. A wrapper that needs the theme's icon family or style should read `useGraphicalIconTheme()` rather than the whole `useGraphicalTheme()` document, so other theme edits don't re-render every icon. Keep its original renderer. `loadIconCatalog('Lucide' | 'Phosphor')` is exported by main, live and native and returns Graphical's separate preview name-to-component map. Use it for a development-only theme preview renderer, not to silently replace the app's original catalog or in production. Set `catalog: { complete: true }` only for a fully enumerated family, or provide `catalog: { complete: false, note: '…' }` explaining a subset. Bare vendor SVGs without a renderer bridge explain why glyph editing is unavailable. Failed loads offer retry; catalog size is never a display cutoff.

On adoption, the agent adds only the accepted icon family as a direct app production dependency when missing, or reuses the app's existing version and wrapper. The editor's transitive dependencies are not production dependencies. If an existing version lacks the selected glyph, report that incompatibility instead of silently upgrading or substituting. Production components never import the editor's preview renderer.

## Assets and updates

The package includes editor JavaScript, declarations, styles, theme data and font/icon references. Free preview icons come from the editor's own dependencies. Your app loads its original fonts and icons; font binaries and licensed icon artwork are not bundled.

To update, install the supplied package version with your app's package manager and follow its accompanying guidance. Preserve the adopted theme, role map, source components and unrelated work.


## Optional style simplification

Import converts the app onto Graphical's system. During setup, the Node-only `analyzeAppStyles` export from `@graphical/editor/analyze-styles` scans all frontend roots and shared UI packages; save the analysis script plus its JSON result. `convertAppStyles({ inventory, document, roleMap, source })` from `@graphical/editor/live` fits Graphical's scales and colors to the app, re-points each app token to one Graphical token and keeps what can't move without a visible change. Pass the result as `conversion`, with its `document` as `initialDocument`; a host Scope applies `resolveHostConversion(document, conversion, { mode })`, and Original canvases receive no `conversion`. The import skill's `references/conversion.md` describes this contract. This is a source inventory, not a crawl of the preview page; dynamic expressions and dependencies outside those roots are not claimed as covered.

With a conversion, the bar reads **Converted to Graphical**. Its info popover tallies, per family, the distinct values that converted, the tokens they became and the values kept as authored. Selecting an element lists its converted values, and **Keep original** keeps them everywhere the app uses them; undo restores the conversion. Contrast is not a gate yet: the preview shows the full impact. Without a conversion, `styleInventory` still enables the earlier optional **Simplify Styles** switch. The selected inspector refreshes when the rewrite stylesheet changes. Use `PreviewFigureFrame` (exported by the main, live and native entry points) for figure holders. It supplies fixed editor geometry and the presentation boundary automatically; app content inside remains editable, without app-specific cleanup logic. Foundation displays marked `data-graphical-foundation` are excluded entirely. Cleanup never changes their corners, padding or other presentation geometry. Preview work is limited to visible elements in small animation-frame batches, with shared CSS rules for peers. It does not rerender host components or scan other routes during edits.

Only an enabled switch includes the plan in the handoff. Refresh its source hashes at installation and apply recorded assignments across the app, with manual edits taking priority. The original source mappings allow independent reversal. The same plan drives the tally and preview; runtime contrast and geometry checks can retain additional exceptions when the current rendered context requires it.
